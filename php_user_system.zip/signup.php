<?php
// Database Connection
$servername = "localhost";
$username = "root";
$password = "your_password";
$dbname = "user_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $reference_id = $_POST['reference_id'];
    $roll = $_POST['roll'];
    $address1 = $_POST['address1'];
    $address2 = $_POST['address2'];
    $city = $_POST['city'];
    $country = $_POST['country'];
    $pin = $_POST['pin'];

    $sql = "INSERT INTO users (name, email, phone, gender, reference_id, roll, address1, address2, city, country, pin) 
            VALUES ('$name', '$email', '$phone', '$gender', '$reference_id', '$roll', '$address1', '$address2', '$city', '$country', '$pin')";

    if ($conn->query($sql) === TRUE) {
        echo "Signup successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
</head>
<body>
    <h2>Signup</h2>
    <form method="POST">
        <label>Name:</label><input type="text" name="name" required><br>
        <label>Email:</label><input type="email" name="email" required><br>
        <label>Phone:</label><input type="text" name="phone" required><br>
        <label>Gender:</label>
        <select name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br>
        <label>Reference ID:</label><input type="text" name="reference_id"><br>
        <label>Roll:</label><input type="text" name="roll"><br>
        <label>Address 1:</label><input type="text" name="address1"><br>
        <label>Address 2:</label><input type="text" name="address2"><br>
        <label>City:</label><input type="text" name="city"><br>
        <label>Country:</label><input type="text" name="country"><br>
        <label>Pin:</label><input type="text" name="pin"><br>
        <button type="submit">Signup</button>
    </form>
</body>
</html>
