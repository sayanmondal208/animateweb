from flask import Flask, request, jsonify
import mysql.connector
import secrets

app = Flask(__name__)

# Database Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'user_db'
}

# Generate API token
@app.route('/generate-token', methods=['POST'])
def generate_token():
    username = request.json.get('username')
    password = request.json.get('password')

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
    user = cursor.fetchone()

    if user and password == password:
        token = secrets.token_hex(16)
        cursor.execute("INSERT INTO api_tokens (user_id, token) VALUES (%s, %s)", (user['id'], token))
        conn.commit()
        return jsonify({'token': token})
    else:
        return jsonify({'error': 'Invalid credentials'}), 401

# Fetch User Data
@app.route('/user-data', methods=['GET'])
def fetch_user_data():
    token = request.headers.get('Authorization')

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM api_tokens WHERE token=%s", (token,))
    token_data = cursor.fetchone()

    if token_data:
        cursor.execute("SELECT * FROM users WHERE id=%s", (token_data['user_id'],))
        user = cursor.fetchone()
        return jsonify(user)
    else:
        return jsonify({'error': 'Invalid token'}), 401

if __name__ == '__main__':
    app.run(debug=True)
